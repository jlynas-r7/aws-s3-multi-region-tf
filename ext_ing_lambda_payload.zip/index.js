var AWS = require('aws-sdk');
AWS.config.update({region: 'us-east-1'});
var ddb = new AWS.DynamoDB({apiVersion: '2012-08-10'});

exports.handler = function(event, context, callback) {
    console.log('Extensible Ingress event:', JSON.stringify(event, null, 4));

    // const json_obj = JSON.parse(JSON.stringify(event, null, 4));
    const json_obj = JSON.parse(JSON.stringify(event));



    // for (var item in json_obj.Records) {
      // for (message in item.Sns.Message.Records) {
        //console.log("My Region is: ", json_obj.Records[0].Sns.Message.Records[0].awsRegion);
        console.log("My Subject is: ", json_obj.Records[0].Sns.Subject);

        let sns_message = json_obj.Records[0].Sns.Message;
        console.log("sns message: ", sns_message);

        const sns_message_obj = JSON.parse(sns_message);
        console.log("awsRegion = ", sns_message_obj.Records[0].awsRegion);


        let aws_region = sns_message_obj.Records[0].awsRegion;
        let event_type = sns_message_obj.Records[0].eventName;
        let filename = sns_message_obj.Records[0].s3.object.key;
        let bucket_arn = sns_message_obj.Records[0].s3.bucket.arn;
        console.log("aws region = ", aws_region);
        console.log("event type = ", event_type);
        console.log("filename = ", filename);
        console.log("bucket arn = ", bucket_arn);

        let file_path_substrings = filename.split('/');
        console.log("Filename substrings = ", file_path_substrings);

      // }
    // }

    var currentdate = new Date();


    //  'filename' : {S: sns_message.Records[0].s3.object.key},
    var params = {
        TableName: 'ext-ing-events-table',
        Item: {
            'timestamp' : {S: currentdate.getTime().toString()},
            'orgid' : {S: file_path_substrings[0]},
            'conid' : {S: file_path_substrings[1]},
            'aws_region' : {S: aws_region},
            'bucket_arn' : {S: bucket_arn},
            'filename' : {S: filename},
            'even_type' : {S: event_type}
        }
    }

    ddb.putItem(params, function(err, data) {
        if (err) {
          console.log("Ext-Ing Dynamo DB Error", err);
        }
    });
};
